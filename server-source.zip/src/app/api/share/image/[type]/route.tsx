import { NextRequest } from "next/server";
import { publicConfig } from "@/config/public-config";
import { getShareImageResponse } from "@/neynar-farcaster-sdk/nextjs";

// Cache for 1 hour - query strings create separate cache entries
export const revalidate = 3600;

const { appEnv, heroImageUrl, imageUrl } = publicConfig;

const showDevWarning = appEnv !== "production";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ type: string }> },
) {
  const { type } = await params;

  return getShareImageResponse(
    { type, heroImageUrl, imageUrl, showDevWarning },
    <div
      style={{
        display: "flex",
        width: "100%",
        height: "100%",
        backgroundColor: "#0f0221",
        flexDirection: "column",
        alignItems: "flex-start",
        justifyContent: "flex-end",
        padding: 60,
      }}
    >
      {/* Microphone icon */}
      <div
        style={{
          display: "flex",
          position: "absolute",
          top: 0,
          right: 0,
          bottom: 0,
          left: 0,
          alignItems: "center",
          justifyContent: "center",
          opacity: 0.07,
        }}
      >
        <div
          style={{
            display: "flex",
            fontSize: 360,
          }}
        >
          🎙️
        </div>
      </div>

      {/* Content card */}
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 16,
        }}
      >
        {/* App name with gradient-style text */}
        <div
          style={{
            display: "flex",
            fontSize: 72,
            fontWeight: "bold",
            color: "white",
            letterSpacing: -2,
            textShadow: "0 0 60px rgba(168,85,247,0.6)",
          }}
        >
          Casting Spaces
        </div>

        {/* Subtitle */}
        <div
          style={{
            display: "flex",
            fontSize: 28,
            color: "rgba(216,180,254,0.85)",
            letterSpacing: 0.5,
          }}
        >
          Live audio rooms on Farcaster
        </div>

        {/* CTA badge */}
        <div
          style={{
            display: "flex",
            marginTop: 12,
            alignItems: "center",
            gap: 12,
            backgroundImage:
              "linear-gradient(135deg, #7c3aed 0%, #ec4899 100%)",
            borderRadius: 100,
            padding: "14px 28px",
            width: "fit-content",
            boxShadow: "0 8px 32px rgba(168,85,247,0.45)",
          }}
        >
          <div style={{ display: "flex", fontSize: 24 }}>🎙️</div>
          <div
            style={{
              display: "flex",
              fontSize: 24,
              fontWeight: "bold",
              color: "white",
            }}
          >
            Join the Space
          </div>
        </div>
      </div>
    </div>,
  );
}
