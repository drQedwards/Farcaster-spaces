"use client";

import { Users, Mic } from "lucide-react";
import { Space } from "@/features/spaces/types";
import { LiveBadge } from "@/features/spaces/components/live-badge";

interface SpaceCardProps {
  space: Space;
  onJoin: (space: Space) => void;
}

export function SpaceCard({ space, onJoin }: SpaceCardProps) {
  return (
    <div
      className="bg-white/5 border border-white/10 rounded-2xl p-4 cursor-pointer hover:bg-white/10 hover:border-purple-500/40 transition-all active:scale-[0.98]"
      onClick={() => onJoin(space)}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          {/* Host avatar */}
          <div className="relative flex-shrink-0">
            <div className="w-11 h-11 rounded-full overflow-hidden border-2 border-purple-500">
              {space.hostPfp ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={space.hostPfp}
                  alt={space.hostName}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-purple-700 flex items-center justify-center text-white font-bold">
                  {space.hostName[0]?.toUpperCase() ?? "?"}
                </div>
              )}
            </div>
          </div>
          {/* Info */}
          <div className="min-w-0">
            <p className="text-white font-semibold text-sm truncate leading-tight">
              {space.title}
            </p>
            <p className="text-purple-300 text-xs mt-0.5 truncate">
              by {space.hostName}
            </p>
          </div>
        </div>
        <LiveBadge />
      </div>

      {/* Stats row */}
      <div className="flex items-center gap-4 mt-3 pt-3 border-t border-white/10">
        <div className="flex items-center gap-1.5 text-gray-400 text-xs">
          <Users className="w-3.5 h-3.5" />
          <span>{space.participantCount} listening</span>
        </div>
        <div className="flex items-center gap-1.5 text-gray-400 text-xs">
          <Mic className="w-3.5 h-3.5" />
          <span>{space.speakerCount} speaking</span>
        </div>
      </div>
    </div>
  );
}
