"use client";

import { useState, useCallback } from "react";
import {
  LiveKitRoom,
  useParticipants,
  useLocalParticipant,
  RoomAudioRenderer,
} from "@livekit/components-react";
import { Mic, MicOff, LogOut, Hand, Users, Radio, MessageCircle } from "lucide-react";
import { Space, SpaceParticipant } from "@/features/spaces/types";
import { SpeakerTile } from "@/features/spaces/components/speaker-tile";
import { LiveBadge } from "@/features/spaces/components/live-badge";
import { SpaceChat } from "@/features/spaces/components/space-chat";
import { ShareButton } from "@/neynar-farcaster-sdk/mini";

type RoomTab = "speakers" | "chat";

interface SpaceRoomInnerProps {
  space: Space;
  currentFid: number;
  currentName: string;
  currentPfp: string;
  isHost: boolean;
  onLeave: () => void;
}

function SpaceRoomInner({
  space,
  currentFid,
  currentName,
  currentPfp,
  isHost,
  onLeave,
}: SpaceRoomInnerProps) {
  const participants = useParticipants();
  const { localParticipant, isMicrophoneEnabled } = useLocalParticipant();
  const [handRaised, setHandRaised] = useState(false);
  const [activeTab, setActiveTab] = useState<RoomTab>("speakers");

  // Build participant list — speakers are those publishing audio
  const speakerParticipants: SpaceParticipant[] = participants
    .filter(
      (p) =>
        p.audioTrackPublications.size > 0 ||
        p.identity === localParticipant.identity
    )
    .map((p) => ({
      fid: parseInt(p.identity.replace("fid_", "") || "0"),
      username: p.name ?? p.identity,
      displayName: p.name ?? p.identity,
      pfpUrl: p.identity === `fid_${currentFid}` ? currentPfp : "",
      role:
        p.identity === `fid_${space.hostFid}`
          ? ("host" as const)
          : ("speaker" as const),
      isMuted: !p.isMicrophoneEnabled,
      isSpeaking: p.isSpeaking,
      joinedAt: Date.now(),
    }));

  const listenerCount = Math.max(
    0,
    participants.length - speakerParticipants.length
  );

  function toggleMic() {
    localParticipant.setMicrophoneEnabled(!isMicrophoneEnabled);
  }

  const toggleHand = useCallback(() => {
    setHandRaised((prev) => {
      const newVal = !prev;
      localParticipant
        .sendText(JSON.stringify({ type: "raiseHand", value: newVal }))
        .catch(console.error);
      return newVal;
    });
  }, [localParticipant]);

  const elapsedMin = space.startedAt
    ? Math.floor((Date.now() - space.startedAt) / 60000)
    : 0;

  return (
    <div className="h-dvh flex flex-col overflow-hidden bg-[#0f0221]">
      <RoomAudioRenderer />

      {/* Header */}
      <header className="shrink-0 px-4 pt-4 pb-3 border-b border-white/5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <LiveBadge />
            {elapsedMin > 0 && (
              <span className="text-gray-500 text-xs">{elapsedMin}m</span>
            )}
          </div>
          <button
            onClick={onLeave}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-red-500/15 text-red-400 text-sm font-medium hover:bg-red-500/25 transition-colors border border-red-500/20"
          >
            <LogOut className="w-3.5 h-3.5" />
            Leave
          </button>
        </div>
        <h1 className="text-white text-lg font-bold mt-2.5 leading-tight line-clamp-1">
          {space.title}
        </h1>
        <div className="flex items-center gap-2 mt-1.5">
          {space.topic && (
            <span className="px-2.5 py-0.5 rounded-full bg-purple-500/20 border border-purple-500/30 text-purple-300 text-xs font-medium">
              {space.topic}
            </span>
          )}
          <span className="text-gray-500 text-xs">by {space.hostName}</span>
        </div>
      </header>

      {/* Tab switcher */}
      <div className="shrink-0 flex gap-1 px-4 pt-3 pb-0">
        <button
          onClick={() => setActiveTab("speakers")}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium transition-all ${
            activeTab === "speakers"
              ? "bg-purple-500/20 text-purple-300 border border-purple-500/30"
              : "text-gray-500 hover:text-gray-400"
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          Speakers
          {speakerParticipants.length > 0 && (
            <span className="text-xs opacity-70">
              {speakerParticipants.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab("chat")}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium transition-all ${
            activeTab === "chat"
              ? "bg-purple-500/20 text-purple-300 border border-purple-500/30"
              : "text-gray-500 hover:text-gray-400"
          }`}
        >
          <MessageCircle className="w-3.5 h-3.5" />
          Chat
        </button>
      </div>

      {/* Tab content */}
      <div className="flex-1 overflow-hidden">
        {/* Speakers tab */}
        {activeTab === "speakers" && (
          <div className="h-full overflow-y-auto px-4 py-4">
            <p className="text-gray-500 text-xs font-semibold uppercase tracking-wider mb-4">
              On stage
            </p>

            {speakerParticipants.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-4">
                  <Mic className="w-7 h-7 text-purple-400/50" />
                </div>
                <p className="text-gray-500 text-sm">No speakers yet</p>
                <p className="text-gray-600 text-xs mt-1">
                  {isHost
                    ? "Unmute to start speaking"
                    : "Raise your hand to speak"}
                </p>
              </div>
            ) : (
              <div className="flex flex-wrap gap-5">
                {speakerParticipants.map((p) => (
                  <SpeakerTile key={p.fid} participant={p} size="md" />
                ))}
              </div>
            )}

            {listenerCount > 0 && (
              <div className="mt-6 pt-4 border-t border-white/10">
                <div className="flex items-center gap-2 text-gray-500 text-xs font-semibold uppercase tracking-wider">
                  <Users className="w-3.5 h-3.5" />
                  <span>{listenerCount} listening</span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Chat tab */}
        {activeTab === "chat" && (
          <SpaceChat currentName={currentName} currentFid={currentFid} />
        )}
      </div>

      {/* Bottom controls */}
      <footer className="shrink-0 px-4 pb-6 pt-3 border-t border-white/10">
        <div className="flex items-center gap-2.5">
          {/* Share */}
          <ShareButton
            text={`🎙️ I'm live in "${space.title}" on Casting Spaces! Come listen in on Farcaster.`}
            variant="ghost"
            size="default"
            className="flex-1 h-12 rounded-2xl bg-white/8 text-white text-sm font-medium hover:bg-white/12 border border-white/10"
          >
            <Radio className="w-4 h-4 mr-1.5" />
            Share
          </ShareButton>

          {/* Raise hand (listeners only) */}
          {!isHost && (
            <button
              onClick={toggleHand}
              className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${
                handRaised
                  ? "bg-yellow-500 text-white shadow-[0_0_16px_rgba(234,179,8,0.4)]"
                  : "bg-white/8 text-white hover:bg-white/12 border border-white/10"
              }`}
              aria-label="Raise hand"
            >
              <Hand className="w-5 h-5" />
            </button>
          )}

          {/* Mic toggle */}
          <button
            onClick={toggleMic}
            className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all shadow-lg ${
              isMicrophoneEnabled
                ? "bg-gradient-to-br from-purple-500 to-pink-500 shadow-[0_0_20px_rgba(168,85,247,0.4)]"
                : "bg-white/8 text-gray-400 hover:bg-white/12 border border-white/10"
            }`}
            aria-label={isMicrophoneEnabled ? "Mute mic" : "Unmute mic"}
          >
            {isMicrophoneEnabled ? (
              <Mic className="w-6 h-6 text-white" />
            ) : (
              <MicOff className="w-6 h-6" />
            )}
          </button>
        </div>

        {isMicrophoneEnabled && (
          <p className="text-center text-purple-300/60 text-xs mt-2">
            You&apos;re live — everyone can hear you 🎙️
          </p>
        )}
      </footer>
    </div>
  );
}

interface SpaceRoomProps {
  space: Space;
  token: string;
  wsUrl: string;
  currentFid: number;
  currentName: string;
  currentPfp: string;
  isHost: boolean;
  onLeave: () => void;
  onShare: (space: Space) => void;
}

export function SpaceRoom({
  space,
  token,
  wsUrl,
  currentFid,
  currentName,
  currentPfp,
  isHost,
  onLeave,
}: SpaceRoomProps) {
  return (
    <LiveKitRoom
      token={token}
      serverUrl={wsUrl}
      connect={true}
      audio={isHost}
      video={false}
      onDisconnected={onLeave}
      className="h-dvh"
    >
      <SpaceRoomInner
        space={space}
        currentFid={currentFid}
        currentName={currentName}
        currentPfp={currentPfp}
        isHost={isHost}
        onLeave={onLeave}
      />
    </LiveKitRoom>
  );
}
