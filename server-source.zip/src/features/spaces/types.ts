export type ParticipantRole = "host" | "speaker" | "listener";

export type SpaceStatus = "scheduled" | "live" | "ended";

export interface SpaceParticipant {
  fid: number;
  username: string;
  displayName: string;
  pfpUrl: string;
  role: ParticipantRole;
  isMuted: boolean;
  isSpeaking: boolean;
  joinedAt: number;
}

export interface Space {
  id: string;
  title: string;
  hostFid: number;
  hostName: string;
  hostPfp: string;
  status: SpaceStatus;
  participantCount: number;
  speakerCount: number;
  topic?: string;
  createdAt: number;
  startedAt?: number;
  endedAt?: number;
}

export type SpaceView = "lobby" | "room";
