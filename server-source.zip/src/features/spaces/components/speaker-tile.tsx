"use client";

import { Mic, MicOff } from "lucide-react";
import { SpaceParticipant } from "@/features/spaces/types";

interface SpeakerTileProps {
  participant: SpaceParticipant;
  size?: "sm" | "md" | "lg";
}

export function SpeakerTile({ participant, size = "md" }: SpeakerTileProps) {
  const sizeClasses = {
    sm: "w-14 h-14",
    md: "w-18 h-18",
    lg: "w-22 h-22",
  };

  const avatarSize = {
    sm: "w-10 h-10",
    md: "w-14 h-14",
    lg: "w-18 h-18",
  };

  const isHost = participant.role === "host";

  return (
    <div className={`flex flex-col items-center gap-1.5 ${sizeClasses[size]}`}>
      <div className="relative">
        {/* Speaking ring animation */}
        {participant.isSpeaking && (
          <span className="absolute inset-0 rounded-full animate-ping bg-purple-400 opacity-40" />
        )}
        <div
          className={`relative ${avatarSize[size]} rounded-full border-2 overflow-hidden ${
            participant.isSpeaking
              ? "border-purple-400 shadow-[0_0_12px_rgba(167,139,250,0.7)]"
              : isHost
                ? "border-pink-400"
                : "border-gray-600"
          }`}
        >
          {participant.pfpUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={participant.pfpUrl}
              alt={participant.displayName}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-purple-700 flex items-center justify-center text-white font-bold text-lg">
              {participant.displayName[0]?.toUpperCase() ?? "?"}
            </div>
          )}
        </div>
        {/* Mic status indicator */}
        <div
          className={`absolute -bottom-0.5 -right-0.5 w-5 h-5 rounded-full flex items-center justify-center ${
            participant.isMuted ? "bg-gray-700" : "bg-purple-500"
          } border-2 border-[#0f0221]`}
        >
          {participant.isMuted ? (
            <MicOff className="w-2.5 h-2.5 text-gray-400" />
          ) : (
            <Mic className="w-2.5 h-2.5 text-white" />
          )}
        </div>
      </div>
      <div className="flex flex-col items-center w-full">
        <span className="text-white text-xs font-medium truncate w-full text-center max-w-[64px]">
          {participant.displayName.split(" ")[0]}
        </span>
        {isHost && (
          <span className="text-pink-400 text-[10px] font-semibold">Host</span>
        )}
      </div>
    </div>
  );
}
