"use client";

import { useState, useEffect, useCallback } from "react";
import { Space } from "@/features/spaces/types";

interface UseLiveSpacesResult {
  spaces: Space[];
  isLoading: boolean;
  isConfigured: boolean;
  refresh: () => void;
}

const POLL_INTERVAL_MS = 15_000; // refresh every 15s

export function useLiveSpaces(): UseLiveSpacesResult {
  const [spaces, setSpaces] = useState<Space[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isConfigured, setIsConfigured] = useState(false);

  const fetchSpaces = useCallback(async () => {
    try {
      const res = await fetch("/api/spaces/list");
      if (!res.ok) return;
      const data = await res.json();
      setIsConfigured(data.configured ?? false);
      setSpaces(data.spaces ?? []);
    } catch {
      // silently fail — show empty state
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSpaces();
    const interval = setInterval(fetchSpaces, POLL_INTERVAL_MS);
    return () => clearInterval(interval);
  }, [fetchSpaces]);

  return { spaces, isLoading, isConfigured, refresh: fetchSpaces };
}
