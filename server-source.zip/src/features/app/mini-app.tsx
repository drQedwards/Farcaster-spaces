"use client";

import { useFarcasterUser } from "@/neynar-farcaster-sdk/mini";
import { SpacesLobby } from "@/features/spaces/components/spaces-lobby";
import { SpaceRoom } from "@/features/spaces/components/space-room";
import { useSpaceSession } from "@/features/spaces/use-space-session";

export function MiniApp() {
  const { data: user } = useFarcasterUser();

  const currentFid = user?.fid ?? 0;
  const currentName =
    user?.displayName ?? user?.username ?? `User ${currentFid}`;
  const currentPfp = user?.pfpUrl ?? "";

  const { session, isJoining, error, joinSpace, leaveSpace } =
    useSpaceSession(currentFid, currentName);

  // LiveKit not configured — show a helpful setup screen
  if (error?.includes("not configured")) {
    return (
      <div className="h-dvh flex flex-col items-center justify-center bg-[#0f0221] px-6 text-center">
        <div className="text-5xl mb-4">🎙️</div>
        <h2 className="text-white text-xl font-bold mb-2">Almost there!</h2>
        <p className="text-purple-300 text-sm leading-relaxed mb-4">
          Casting Spaces needs LiveKit credentials to power live audio. Get your
          free API keys at{" "}
          <span className="text-purple-400 font-semibold">livekit.io</span>
          , then add them to your environment:
        </p>
        <div className="bg-white/5 border border-white/10 rounded-xl p-4 text-left w-full max-w-xs">
          <code className="text-xs text-purple-300 leading-loose">
            <div>LIVEKIT_API_KEY=...</div>
            <div>LIVEKIT_API_SECRET=...</div>
            <div>LIVEKIT_URL=wss://...</div>
            <div>NEXT_PUBLIC_LIVEKIT_URL=wss://...</div>
          </code>
        </div>
        <button
          onClick={() => window.location.reload()}
          className="mt-6 px-6 py-2.5 rounded-full bg-gradient-to-r from-purple-600 to-pink-500 text-white text-sm font-semibold shadow-[0_4px_16px_rgba(168,85,247,0.35)]"
        >
          Retry
        </button>
      </div>
    );
  }

  // Inside a live room
  if (session) {
    return (
      <SpaceRoom
        space={session.space}
        token={session.token}
        wsUrl={session.wsUrl}
        currentFid={currentFid}
        currentName={currentName}
        currentPfp={currentPfp}
        isHost={session.isHost}
        onLeave={leaveSpace}
        onShare={() => {}}
      />
    );
  }

  // Lobby
  return (
    <SpacesLobby
      onJoinSpace={joinSpace}
      currentUserName={currentName}
      currentUserFid={currentFid}
      currentUserPfp={currentPfp}
      isJoining={isJoining}
    />
  );
}
