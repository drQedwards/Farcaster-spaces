"use client";

import { useState } from "react";
import { Mic, Radio, Sparkles, RefreshCw, Wifi } from "lucide-react";
import { Space } from "@/features/spaces/types";
import { SpaceCard } from "@/features/spaces/components/space-card";
import { CreateSpaceSheet } from "@/features/spaces/components/create-space-sheet";
import { ShareButton } from "@/neynar-farcaster-sdk/mini";
import { useLiveSpaces } from "@/features/spaces/use-live-spaces";

interface SpacesLobbyProps {
  onJoinSpace: (space: Space, asHost: boolean) => Promise<void>;
  currentUserName: string;
  currentUserFid: number;
  currentUserPfp: string;
  isJoining: boolean;
}

export function SpacesLobby({
  onJoinSpace,
  currentUserName,
  currentUserFid,
  currentUserPfp,
  isJoining,
}: SpacesLobbyProps) {
  const [showCreate, setShowCreate] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const { spaces, isLoading, isConfigured, refresh } = useLiveSpaces();

  async function handleCreate(title: string, topic: string) {
    setIsCreating(true);
    const newSpace: Space = {
      id: `${Date.now()}`,
      title,
      hostFid: currentUserFid,
      hostName: currentUserName,
      hostPfp: currentUserPfp,
      status: "live",
      participantCount: 1,
      speakerCount: 1,
      topic: topic || undefined,
      createdAt: Date.now(),
      startedAt: Date.now(),
    };
    await onJoinSpace(newSpace, true);
    setIsCreating(false);
    setShowCreate(false);
  }

  return (
    <div className="h-dvh flex flex-col overflow-hidden bg-[#0f0221]">
      {/* Header */}
      <header className="shrink-0 px-4 pt-5 pb-4">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center shadow-[0_0_12px_rgba(168,85,247,0.4)]">
            <Radio className="w-4 h-4 text-white" />
          </div>
          <h1 className="text-white text-xl font-bold tracking-tight">
            Casting Spaces
          </h1>
          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={refresh}
              className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
              aria-label="Refresh spaces"
            >
              <RefreshCw className="w-3.5 h-3.5 text-gray-400" />
            </button>
            <ShareButton
              text="🎙️ Join me on Casting Spaces — live audio rooms on Farcaster! Your voice, your cast."
              variant="ghost"
              size="icon"
              className="w-8 h-8 rounded-full bg-white/10 text-white hover:bg-white/20"
            >
              <Radio className="w-4 h-4" />
            </ShareButton>
          </div>
        </div>
        <p className="text-purple-300/70 text-sm pl-10">
          Live audio rooms on Farcaster
        </p>
      </header>

      {/* Start Space CTA */}
      <div className="shrink-0 px-4 pb-4">
        <button
          onClick={() => setShowCreate(true)}
          className="w-full h-14 rounded-2xl bg-gradient-to-r from-purple-600 to-pink-500 flex items-center justify-center gap-2.5 text-white font-bold text-base shadow-[0_4px_24px_rgba(168,85,247,0.4)] hover:opacity-95 active:scale-[0.98] transition-all"
        >
          <Mic className="w-5 h-5" />
          Start a Space
        </button>
      </div>

      {/* Live Spaces list */}
      <main className="flex-1 overflow-y-auto px-4">
        {/* Section header */}
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="w-4 h-4 text-purple-400" />
          <p className="text-white text-sm font-semibold">Live now</p>
          {!isLoading && spaces.length > 0 && (
            <span className="ml-auto text-gray-500 text-xs">
              {spaces.length} space{spaces.length !== 1 ? "s" : ""}
            </span>
          )}
        </div>

        {/* Loading state */}
        {isLoading && (
          <div className="space-y-3">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="bg-white/5 border border-white/10 rounded-2xl p-4 animate-pulse"
              >
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full bg-white/10" />
                  <div className="flex-1 space-y-2">
                    <div className="h-3.5 bg-white/10 rounded-full w-3/4" />
                    <div className="h-3 bg-white/5 rounded-full w-1/2" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Spaces list */}
        {!isLoading && spaces.length > 0 && (
          <div className="space-y-3 pb-6">
            {spaces.map((space) => (
              <SpaceCard
                key={space.id}
                space={space}
                onJoin={(s) => onJoinSpace(s, false)}
              />
            ))}
          </div>
        )}

        {/* Empty state — no spaces yet */}
        {!isLoading && spaces.length === 0 && (
          <div className="flex flex-col items-center justify-center py-14 text-center">
            <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-4">
              {isConfigured ? (
                <Mic className="w-7 h-7 text-purple-400" />
              ) : (
                <Wifi className="w-7 h-7 text-purple-400" />
              )}
            </div>
            <p className="text-white font-semibold mb-1">
              {isConfigured ? "No spaces live right now" : "Ready to launch"}
            </p>
            <p className="text-gray-500 text-sm max-w-[220px] leading-relaxed">
              {isConfigured
                ? "Be the first to start one — tap the button above"
                : "Add your LiveKit API keys to enable live audio, then start your first Space"}
            </p>
            {!isConfigured && (
              <div className="mt-4 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-left max-w-[260px]">
                <code className="text-xs text-purple-300 leading-loose">
                  <div>LIVEKIT_API_KEY=...</div>
                  <div>LIVEKIT_API_SECRET=...</div>
                  <div>LIVEKIT_URL=wss://...</div>
                  <div>NEXT_PUBLIC_LIVEKIT_URL=wss://...</div>
                </code>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Joining overlay */}
      {isJoining && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-40">
          <div className="bg-[#1a0533] border border-white/10 rounded-2xl p-6 text-center mx-4">
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center mx-auto mb-3 shadow-[0_0_24px_rgba(168,85,247,0.5)]">
              <Mic className="w-7 h-7 text-white animate-pulse" />
            </div>
            <p className="text-white font-semibold">Joining Space...</p>
            <p className="text-gray-500 text-sm mt-1">Setting up audio</p>
          </div>
        </div>
      )}

      {showCreate && (
        <CreateSpaceSheet
          onClose={() => setShowCreate(false)}
          onCreate={handleCreate}
          isCreating={isCreating}
        />
      )}
    </div>
  );
}
