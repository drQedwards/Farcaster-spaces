"use client";

import { useState, useCallback } from "react";
import { Space } from "@/features/spaces/types";

interface SpaceSession {
  space: Space;
  token: string;
  wsUrl: string;
  isHost: boolean;
}

interface UseSpaceSessionResult {
  session: SpaceSession | null;
  isJoining: boolean;
  error: string | null;
  joinSpace: (space: Space, asHost: boolean) => Promise<void>;
  leaveSpace: () => void;
}

export function useSpaceSession(
  currentFid: number,
  currentName: string
): UseSpaceSessionResult {
  const [session, setSession] = useState<SpaceSession | null>(null);
  const [isJoining, setIsJoining] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const joinSpace = useCallback(
    async (space: Space, asHost: boolean) => {
      setIsJoining(true);
      setError(null);

      try {
        const role = asHost ? "host" : "listener";
        const roomName = `space-${space.id}`;

        // If host, register the room metadata so it shows in the list
        if (asHost) {
          await fetch("/api/spaces/create", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              spaceId: space.id,
              title: space.title,
              hostFid: space.hostFid,
              hostName: space.hostName,
              hostPfp: space.hostPfp,
              topic: space.topic,
            }),
          });
        }

        const res = await fetch("/api/spaces/token", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            roomName,
            participantName: currentName,
            participantFid: currentFid,
            role,
          }),
        });

        const data = await res.json();

        if (!res.ok || data.error) {
          setError(data.error ?? "Failed to join space");
          return;
        }

        const wsUrl =
          process.env.NEXT_PUBLIC_LIVEKIT_URL ??
          "wss://casting-spaces.livekit.cloud";

        setSession({ space, token: data.token, wsUrl, isHost: asHost });
      } catch (err) {
        setError("Could not connect. Please try again.");
        console.error(err);
      } finally {
        setIsJoining(false);
      }
    },
    [currentFid, currentName]
  );

  const leaveSpace = useCallback(() => {
    setSession(null);
    setError(null);
  }, []);

  return { session, isJoining, error, joinSpace, leaveSpace };
}
