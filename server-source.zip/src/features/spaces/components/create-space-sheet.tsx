"use client";

import { useState } from "react";
import { X, Mic } from "lucide-react";

interface CreateSpaceSheetProps {
  onClose: () => void;
  onCreate: (title: string, topic: string) => void;
  isCreating: boolean;
}

export function CreateSpaceSheet({
  onClose,
  onCreate,
  isCreating,
}: CreateSpaceSheetProps) {
  const [title, setTitle] = useState("");
  const [topic, setTopic] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    onCreate(title.trim(), topic.trim());
  }

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Sheet */}
      <div className="relative bg-[#1a0533] border-t border-white/10 rounded-t-3xl p-6 pb-8">
        {/* Handle */}
        <div className="absolute top-3 left-1/2 -translate-x-1/2 w-10 h-1 bg-white/20 rounded-full" />

        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-white text-xl font-bold">Start a Space</h2>
            <p className="text-purple-300 text-sm mt-0.5">
              Your voice, your cast
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
          >
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Icon */}
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center shadow-[0_0_24px_rgba(168,85,247,0.4)]">
            <Mic className="w-7 h-7 text-white" />
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-gray-300 text-sm font-medium block mb-1.5">
              Space title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="What are we talking about?"
              maxLength={80}
              className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-purple-400 focus:bg-white/15 transition-all"
              autoFocus
            />
          </div>

          <div>
            <label className="text-gray-300 text-sm font-medium block mb-1.5">
              Topic{" "}
              <span className="text-gray-500 font-normal">(optional)</span>
            </label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. Farcaster, crypto, music..."
              maxLength={50}
              className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-purple-400 focus:bg-white/15 transition-all"
            />
          </div>

          <button
            type="submit"
            disabled={!title.trim() || isCreating}
            className="w-full h-13 mt-2 rounded-2xl bg-gradient-to-r from-purple-600 to-pink-500 text-white font-bold text-base disabled:opacity-40 disabled:cursor-not-allowed hover:opacity-90 active:scale-[0.98] transition-all shadow-[0_4px_20px_rgba(168,85,247,0.3)]"
          >
            {isCreating ? "Starting..." : "Go Live 🎙️"}
          </button>
        </form>
      </div>
    </div>
  );
}
