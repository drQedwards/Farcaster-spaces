"use client";

interface LiveBadgeProps {
  pulse?: boolean;
  className?: string;
}

export function LiveBadge({ pulse = true, className = "" }: LiveBadgeProps) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-pink-500 text-white text-xs font-bold uppercase tracking-wide ${className}`}
    >
      {pulse && (
        <span className="relative flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75" />
          <span className="relative inline-flex rounded-full h-2 w-2 bg-white" />
        </span>
      )}
      Live
    </span>
  );
}
