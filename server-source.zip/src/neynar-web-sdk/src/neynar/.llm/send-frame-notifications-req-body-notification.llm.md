# SendFrameNotificationsReqBodyNotification

**Type**: type

Send frame notifications request body notification

Notification content and configuration for frame notifications. This object is nested under the `notification` key in the request body — it is NOT sent as top-level fields.

**Properties:**

- `title: string` - Notification title. Must be between 1 and 32 characters. Appears as the push notification header.
- `body: string` - Notification body text. Must be between 1 and 128 characters. Appears as the push notification message.
- `target_url: string` - URL to open when the user taps the notification. Must be a valid URL (max 1024 characters). Use `publicConfig.homeUrl` for your app's URL.
- `uuid?: string` - Optional UUID used as an idempotency key to prevent duplicate notifications.

## Request Body Structure

The full request body for `POST /v2/farcaster/frame/notifications` is:

```json
{
  "target_fids": [123, 456],
  "notification": {
    "title": "Someone collected your photo!",
    "body": "@username collected \"Photo Title\"",
    "target_url": "https://your-app-url.com"
  }
}
```

**IMPORTANT**:
- `title`, `body`, and `target_url` MUST be nested inside a `notification` object. Do NOT send them as top-level fields.
- `target_fids` is **required**. Pass an empty array `[]` to broadcast to all subscribers with notifications enabled.

## Common Mistakes

```typescript
// ❌ WRONG - fields at top level, wrong field names
{
  frame_url: publicConfig.homeUrl,
  title: "Hey!",
  message: "Something happened",
  target_fids: [123],
}

// ✅ CORRECT - nested under notification, correct field names
{
  target_fids: [123],
  notification: {
    title: "Hey!",
    body: "Something happened",
    target_url: publicConfig.homeUrl,
  },
}

// ✅ CORRECT - broadcast to all subscribers
{
  target_fids: [], // empty array = all subscribers
  notification: {
    title: "Announcement",
    body: "New feature available!",
    target_url: publicConfig.homeUrl,
  },
}
```
