"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { useLocalParticipant, useDataChannel } from "@livekit/components-react";
import { Send } from "lucide-react";

export interface ChatMessage {
  id: string;
  senderName: string;
  senderFid: number;
  text: string;
  timestamp: number;
  isLocal: boolean;
  reaction?: boolean;
}

const QUICK_REACTIONS = ["🔥", "👏", "🎙️", "💜", "😂", "🚀"];

const CHAT_TOPIC = "chat";

interface SpaceChatProps {
  currentName: string;
  currentFid: number;
}

export function SpaceChat({ currentName, currentFid }: SpaceChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { localParticipant } = useLocalParticipant();

  // Receive messages from other participants
  const { message: incoming } = useDataChannel(CHAT_TOPIC);

  useEffect(() => {
    if (!incoming?.payload) return;
    try {
      const decoded = new TextDecoder().decode(incoming.payload);
      const msg = JSON.parse(decoded) as ChatMessage;
      setMessages((prev) => {
        // deduplicate by id
        if (prev.some((m) => m.id === msg.id)) return prev;
        return [...prev, { ...msg, isLocal: false }];
      });
    } catch {}
  }, [incoming]);

  // Auto-scroll to latest message
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = useCallback(
    (text: string, reaction = false) => {
      if (!text.trim()) return;
      const msg: ChatMessage = {
        id: `${currentFid}-${Date.now()}`,
        senderName: currentName,
        senderFid: currentFid,
        text: text.trim(),
        timestamp: Date.now(),
        isLocal: true,
        reaction,
      };
      // Optimistically add locally
      setMessages((prev) => [...prev, msg]);
      // Broadcast to room
      const encoded = new TextEncoder().encode(JSON.stringify(msg));
      localParticipant
        .publishData(encoded, { topic: CHAT_TOPIC, reliable: true })
        .catch(console.error);
    },
    [currentFid, currentName, localParticipant]
  );

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!input.trim()) return;
    sendMessage(input);
    setInput("");
  }

  return (
    <div className="flex flex-col h-full">
      {/* Quick reactions */}
      <div className="shrink-0 flex gap-2 px-4 py-2.5 border-b border-white/5">
        {QUICK_REACTIONS.map((r) => (
          <button
            key={r}
            onClick={() => sendMessage(r, true)}
            className="flex-1 h-9 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 transition-all text-lg flex items-center justify-center"
            aria-label={`React with ${r}`}
          >
            {r}
          </button>
        ))}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center py-10">
            <div className="text-3xl mb-2">💬</div>
            <p className="text-gray-500 text-sm">No messages yet</p>
            <p className="text-gray-600 text-xs mt-1">
              Be the first to say something!
            </p>
          </div>
        )}

        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-start gap-2.5 ${msg.isLocal ? "flex-row-reverse" : ""}`}
          >
            {/* Avatar */}
            <div className="shrink-0 w-7 h-7 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white text-xs font-bold">
              {msg.senderName[0]?.toUpperCase() ?? "?"}
            </div>

            {/* Bubble */}
            {msg.reaction ? (
              <div className="text-2xl leading-none">{msg.text}</div>
            ) : (
              <div
                className={`max-w-[75%] rounded-2xl px-3 py-2 ${
                  msg.isLocal
                    ? "bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-tr-sm"
                    : "bg-white/8 text-white rounded-tl-sm border border-white/10"
                }`}
              >
                {!msg.isLocal && (
                  <p className="text-purple-300 text-[10px] font-semibold mb-0.5">
                    {msg.senderName}
                  </p>
                )}
                <p className="text-sm leading-relaxed break-words">{msg.text}</p>
              </div>
            )}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <form
        onSubmit={handleSubmit}
        className="shrink-0 flex items-center gap-2 px-4 py-3 border-t border-white/5"
      >
        <input
          ref={inputRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Say something..."
          maxLength={280}
          className="flex-1 h-11 rounded-2xl bg-white/8 border border-white/10 px-4 text-white text-sm placeholder:text-gray-600 outline-none focus:border-purple-500/50 focus:bg-white/10 transition-all"
        />
        <button
          type="submit"
          disabled={!input.trim()}
          className="w-11 h-11 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center disabled:opacity-30 disabled:cursor-not-allowed hover:opacity-90 active:scale-95 transition-all shadow-[0_2px_12px_rgba(168,85,247,0.3)]"
        >
          <Send className="w-4 h-4 text-white" />
        </button>
      </form>
    </div>
  );
}
